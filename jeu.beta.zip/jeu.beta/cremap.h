int **creamap();
void affichagemap(int **map);
int deplacement(char choix, int **map, int* searchpers);
