typedef struct personnage personnage;

struct personnage
{
    char *name;
    int pv;
    int att;
    int def;
};

