int choix(char PlayerChoice);
