int **creamap();
void affichagemap(int **map);
