int* search_personnage(int **creamap, int personnage);
