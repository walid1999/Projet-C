#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED
void affichageMenu();


#endif // menu_H_INCLUDED

