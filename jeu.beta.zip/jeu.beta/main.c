#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
int main()
{
    affichageMenu();
    return 0;
}

